import { strFromU8, unzipSync } from "fflate";
import { scoreAssessment } from "../../engine/scoring/scorers";
import { validateAssessmentPackage, type AssessmentPackage } from "../../schema/assessmentSchema";
import type { Answers, AssessmentResult } from "../../engine/result/types";

export const previewZipLimits = {
  maxZipBytes: 10 * 1024 * 1024,
  maxFiles: 200,
  maxUncompressedBytes: 20 * 1024 * 1024
} as const;

export interface AcceptanceCase {
  id: string;
  title: string;
  answers: Answers;
  expectedResultId?: string;
}

export interface AcceptanceCaseRun {
  caseData: AcceptanceCase;
  actualResultId?: string;
  passed: boolean;
  result?: AssessmentResult;
  error?: string;
}

export interface PreviewPackageLoadResult {
  acceptanceCases: AcceptanceCase[];
  assessment?: AssessmentPackage;
  designReport?: string;
  errors: string[];
  rawPackage?: unknown;
  schemaStatus: "pass" | "fail";
  warnings: string[];
}

interface ZipEntry {
  path: string;
  data: Uint8Array;
}

export function loadPreviewPackageFromZip(input: Uint8Array, zipSize = input.byteLength): PreviewPackageLoadResult {
  const warnings: string[] = [];
  const errors: string[] = [];

  if (zipSize > previewZipLimits.maxZipBytes) {
    return fail([`ZIP is too large: ${zipSize} bytes. Maximum is ${previewZipLimits.maxZipBytes} bytes.`]);
  }

  let entries: ZipEntry[];
  try {
    entries = Object.entries(unzipSync(input)).map(([path, data]) => ({ path: normalizeZipPath(path), data }));
  } catch (error) {
    return fail([`Could not unzip package: ${error instanceof Error ? error.message : String(error)}`]);
  }

  if (entries.length > previewZipLimits.maxFiles) {
    return fail([`ZIP contains too many files: ${entries.length}. Maximum is ${previewZipLimits.maxFiles}.`]);
  }

  const unsafePath = entries.find((entry) => !isSafeZipPath(entry.path));
  if (unsafePath) {
    return fail([`Unsafe ZIP path rejected: ${unsafePath.path}`]);
  }

  const totalBytes = entries.reduce((sum, entry) => sum + entry.data.byteLength, 0);
  if (totalBytes > previewZipLimits.maxUncompressedBytes) {
    return fail([`ZIP uncompressed content is too large: ${totalBytes} bytes. Maximum is ${previewZipLimits.maxUncompressedBytes}.`]);
  }

  const testJsonEntries = entries.filter((entry) => basename(entry.path) === "test.json");
  if (testJsonEntries.length === 0) {
    return fail(["No test.json found in ZIP."]);
  }
  if (testJsonEntries.length > 1) {
    return fail([`Multiple test.json files found: ${testJsonEntries.map((entry) => entry.path).join(", ")}`]);
  }

  const rawPackage = parseJson(testJsonEntries[0], errors);
  if (rawPackage === undefined) {
    return fail(errors);
  }

  const validation = validateAssessmentPackage(rawPackage);
  const acceptanceCases = loadOptionalAcceptanceCases(entries, warnings, errors);
  const designReport = loadOptionalText(entries, "design-report.md", warnings);

  if (!validation.success) {
    return {
      acceptanceCases,
      designReport,
      errors: [...errors, ...validation.errors],
      rawPackage,
      schemaStatus: "fail",
      warnings
    };
  }

  return {
    acceptanceCases,
    assessment: validation.data,
    designReport,
    errors,
    rawPackage,
    schemaStatus: "pass",
    warnings
  };
}

export function runAcceptanceCase(assessment: AssessmentPackage, caseData: AcceptanceCase): AcceptanceCaseRun {
  try {
    const result = scoreAssessment(assessment, caseData.answers);
    const actualResultId = result.primaryResult?.id;
    return {
      actualResultId,
      caseData,
      passed: Boolean(caseData.expectedResultId && actualResultId === caseData.expectedResultId),
      result
    };
  } catch (error) {
    return {
      caseData,
      error: error instanceof Error ? error.message : String(error),
      passed: false
    };
  }
}

export function runAcceptanceCases(assessment: AssessmentPackage, cases: AcceptanceCase[]) {
  return cases.map((caseData) => runAcceptanceCase(assessment, caseData));
}

function fail(errors: string[]): PreviewPackageLoadResult {
  return {
    acceptanceCases: [],
    errors,
    schemaStatus: "fail",
    warnings: []
  };
}

function loadOptionalAcceptanceCases(entries: ZipEntry[], warnings: string[], errors: string[]) {
  const matches = entries.filter((entry) => basename(entry.path) === "acceptance-cases.json");
  if (matches.length === 0) {
    return [];
  }
  if (matches.length > 1) {
    warnings.push(`Multiple acceptance-cases.json files found; using ${matches[0].path}.`);
  }
  const parsed = parseJson(matches[0], errors);
  if (parsed === undefined) {
    return [];
  }
  const rawCases = Array.isArray(parsed)
    ? parsed
    : isRecord(parsed) && Array.isArray(parsed.cases)
      ? parsed.cases
      : undefined;
  if (!rawCases) {
    errors.push("acceptance-cases.json must be an array or an object with a cases array.");
    return [];
  }
  return rawCases.flatMap((item, index) => normalizeAcceptanceCase(item, index, warnings));
}

function normalizeAcceptanceCase(input: unknown, index: number, warnings: string[]): AcceptanceCase[] {
  if (!isRecord(input) || !isRecord(input.answers)) {
    warnings.push(`Acceptance case ${index + 1} is missing answers and was ignored.`);
    return [];
  }
  const expectedResultId =
    typeof input.expectedResultId === "string"
      ? input.expectedResultId
      : isRecord(input.expected) && typeof input.expected.primaryResultId === "string"
        ? input.expected.primaryResultId
        : undefined;
  if (!expectedResultId) {
    warnings.push(`Acceptance case ${index + 1} is missing expectedResultId and was ignored.`);
    return [];
  }
  return [
    {
      id: typeof input.id === "string" ? input.id : `case-${index + 1}`,
      title: typeof input.title === "string" ? input.title : `Case ${index + 1}`,
      answers: Object.fromEntries(Object.entries(input.answers).filter((entry): entry is [string, string] => typeof entry[1] === "string")),
      expectedResultId
    }
  ];
}

function loadOptionalText(entries: ZipEntry[], fileName: string, warnings: string[]) {
  const matches = entries.filter((entry) => basename(entry.path).toLowerCase() === fileName);
  if (matches.length === 0) {
    return undefined;
  }
  if (matches.length > 1) {
    warnings.push(`Multiple ${fileName} files found; using ${matches[0].path}.`);
  }
  return strFromU8(matches[0].data);
}

function parseJson(entry: ZipEntry, errors: string[]) {
  try {
    return JSON.parse(strFromU8(entry.data));
  } catch (error) {
    errors.push(`${entry.path} is not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
    return undefined;
  }
}

function normalizeZipPath(path: string) {
  return path.replace(/\\/g, "/");
}

function isSafeZipPath(path: string) {
  return !path.startsWith("/") && !/^[a-zA-Z]:\//.test(path) && !path.split("/").some((segment) => segment === "..");
}

function basename(path: string) {
  const parts = path.split("/").filter(Boolean);
  return parts.at(-1) ?? "";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
