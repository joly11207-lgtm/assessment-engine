import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { strToU8, zipSync } from "fflate";
import { scoreAssessment } from "../engine/scoring/scorers";
import { registeredAssessments } from "../registry/assessmentRegistry";
import { loadPreviewPackageFromZip, runAcceptanceCases } from "../app/preview/zipPreviewLoader";

const personality = registeredAssessments.find((assessment) => assessment.metadata.id === "demo-personality");
assert.ok(personality);

const validAnswers = Object.fromEntries(personality.questions.map((question) => [question.id, question.options[0].id]));
const validResult = scoreAssessment(personality, validAnswers);
assert.ok(validResult.primaryResult);

describe("ZIP Test Previewer loader", () => {
  it("loads a root-level test.json", () => {
    const loaded = loadPreviewPackageFromZip(makeZip({ "test.json": JSON.stringify(personality) }));

    assert.equal(loaded.schemaStatus, "pass");
    assert.equal(loaded.assessment?.metadata.id, "demo-personality");
  });

  it("loads a test.json inside one top-level folder", () => {
    const loaded = loadPreviewPackageFromZip(makeZip({ "package/test.json": JSON.stringify(personality) }));

    assert.equal(loaded.schemaStatus, "pass");
    assert.equal(loaded.assessment?.metadata.id, "demo-personality");
  });

  it("rejects ZIPs without test.json", () => {
    const loaded = loadPreviewPackageFromZip(makeZip({ "readme.md": "no package here" }));

    assert.equal(loaded.schemaStatus, "fail");
    assert.match(loaded.errors.join("\n"), /No test\.json/);
  });

  it("rejects multiple test.json files instead of guessing", () => {
    const loaded = loadPreviewPackageFromZip(
      makeZip({
        "one/test.json": JSON.stringify(personality),
        "two/test.json": JSON.stringify(personality)
      })
    );

    assert.equal(loaded.schemaStatus, "fail");
    assert.match(loaded.errors.join("\n"), /Multiple test\.json/);
  });

  it("surfaces schema errors and does not produce a runnable assessment", () => {
    const invalid = {
      ...personality,
      metadata: { ...personality.metadata, id: "bad id with spaces" }
    };
    const loaded = loadPreviewPackageFromZip(makeZip({ "test.json": JSON.stringify(invalid) }));

    assert.equal(loaded.schemaStatus, "fail");
    assert.equal(loaded.assessment, undefined);
    assert.match(loaded.errors.join("\n"), /ids may only contain/);
  });

  it("runs acceptance cases through the real scoring engine with pass and fail results", () => {
    const cases = [
      {
        id: "pass",
        title: "Expected primary result",
        answers: validAnswers,
        expectedResultId: validResult.primaryResult?.id
      },
      {
        id: "fail",
        title: "Wrong expected result",
        answers: validAnswers,
        expectedResultId: "not-the-real-result"
      }
    ];
    const loaded = loadPreviewPackageFromZip(
      makeZip({
        "test.json": JSON.stringify(personality),
        "acceptance-cases.json": JSON.stringify(cases),
        "design-report.md": "# Design"
      })
    );

    assert.equal(loaded.schemaStatus, "pass");
    assert.equal(loaded.acceptanceCases.length, 2);
    assert.equal(loaded.designReport, "# Design");
    assert.ok(loaded.assessment);
    const runs = runAcceptanceCases(loaded.assessment, loaded.acceptanceCases);
    assert.equal(runs[0].passed, true);
    assert.equal(runs[1].passed, false);
    assert.equal(runs[0].actualResultId, validResult.primaryResult?.id);
  });

  it("keeps existing registered fixtures runnable", () => {
    registeredAssessments.forEach((assessment) => {
      const answers = Object.fromEntries(assessment.questions.map((question) => [question.id, question.options[0].id]));
      const result = scoreAssessment(assessment, answers);

      assert.equal(result.metadata.assessmentId, assessment.metadata.id);
      assert.ok(result.primaryResult);
    });
  });
});

function makeZip(files: Record<string, string>) {
  return zipSync(Object.fromEntries(Object.entries(files).map(([path, content]) => [path, strToU8(content)])));
}
